# Aji-4 edition — results

Two runs were executed on this machine (2 CPU cores, 1,982 MB RAM, no GPU). Neither is a
trained model; both exist to show the pipeline is correct end to end.

---

## Run A — full package smoke test

Proves the **entire 272-flood / 234-training-flood package** loads and trains. Config:
`configs/aji4_full_smoke_cpu.yaml` (2 epochs × 25 steps, batch 1 with
`grad_accum_steps: 8` → effective batch 8).

```
Mesh topology    : 15,990 nodes | 63,960 directed edges
Node features    : 16 (9 static + 3 forcing + 2*2 history)
Train windows    : 34,938 across 234 floods (train.txt + val.txt)
Burst onset      : row 8-39 (median 32, hour 16.0)
Test rollouts    : 38 hydrographs x 40 steps
Trainable params : 214,210
```

| epoch | time | L_pred | depth | volume |
|---|---|---|---|---|
| 1 | 29.4 s | 0.01801 | 0.01192 | 0.02409 |
| 2 | 29.0 s | 0.00391 | 0.00476 | 0.00306 |

After 2 epochs (50 steps, 1,200 flood-windows seen) the 40-step rollout on all 38 test
floods gives **RMSE 3.02 m, NSE −5.53**. That is exactly what two epochs should look like:
the loss is falling, the loader and rollout machinery work, and the weights are nowhere
near converged.

Peak RSS stayed at **~1.6 GB**, which is why `batch_size: 1` is used — a batch of two
15,990-node graphs needs more than this machine has. Full training is a GPU job:
≈29 s per epoch here would be ≈40 h for the 150-epoch recipe.

**Checkpoints:** `checkpoints_full_smoke/{best,latest}.pt` (2.7 MB each).
**History:** `outputs_full_smoke/training_history.json`.

---

## Run B — subset, trained

Config: `configs/aji4_subset_cpu.yaml`. 6 training floods (train ∪ val) → **913 windows**;
2 test floods (R004, R008). 26,274 parameters, 12 epochs × 30 steps, **2 m 20 s** total.

| epoch | L_pred | Val Rollout RMSE | NSE | CSI@0.05 | CSI@0.30 | VolErr |
|---|---|---|---|---|---|---|
| 4 | 0.00110 | 0.3723 m | 0.9127 | 0.624 | 0.808 | 26.8 % |
| 8 | 0.00130 | 0.4182 m | 0.8900 | 0.735 | 0.850 | 28.1 % |
| 12 | 0.00176 | 0.3796 m | 0.9093 | 0.598 | 0.822 | 21.9 % |

### Test rollouts — 2 floods × 40 steps (20 h)

| metric | value |
|---|---|
| RMSE | **0.36430 m** |
| MAE | 0.21084 m |
| NSE | **0.91616** |
| CSI @ 0.05 m | 0.49584 |
| CSI @ 0.30 m | 0.73046 |
| Final-step RMSE | 0.71297 m |
| Total-volume RMSE | 5.96 Mm³ |
| Rel. total-volume error | 22.998 % |

### Baselines on the same horizon

| forecaster | RMSE |
|---|---|
| **Persistence** (hold and clamp t0 depth) | **0.31210 m** |
| Zero-forecast | 1.42367 m |
| HydroGraphNet (subset, 12 epochs) | 0.36430 m |

The two numbers are close because persistence is a strong baseline on a rising limb, which
is why it is reported here at all. Broken out by lead time it is not close:

| lead time | model RMSE | persistence | winner |
|---|---|---|---|
| 0.5 h | 0.0248 m | 0.3121 m | model, 12.6× |
| 5 h | 0.1731 m | 0.3121 m | model, 1.8× |
| 10 h | 0.2849 m | 0.3121 m | model |
| **11.5 h** | **0.3121 m** | 0.3121 m | **crossover** |
| 15 h | 0.4235 m | 0.3121 m | persistence |
| 20 h | 0.7130 m | 0.3121 m | persistence |

So the model beats "the water stays where it is" for the first **11.5 hours** and loses
afterwards, which is what a 6-flood / 12-epoch / 2-core run should do. Per flood: R004
0.3267 m, R008 0.4019 m — R008 is the harder one. The subset run's job is to prove the
two-split loader, the 16-feature graph, the Δdepth/Δvolume target, the rollout driver and
the metrics all work; beating persistence past 12 h needs the full 234 floods and a GPU.

Figures: `outputs_subset/rmse_over_time.png`, `outputs_subset/rollout_R004.png`,
`outputs_subset/rollout_R008.png`. Metrics JSON: `outputs_subset/evaluation_metrics.json`.

---

## Reproduce

```bash
pip install -r requirements.txt

# Run A
python train.py --config configs/aji4_full_smoke_cpu.yaml

# Run B
python tools/make_subset.py --src /path/to/aji4_flood_data_G1O \
       --dst ./data/aji4_subset_G1O \
       --train R001 R002 R011 R021 --val R031 R041 --test R004 R008
python train.py    --config configs/aji4_subset_cpu.yaml
python evaluate.py --config configs/aji4_subset_cpu.yaml
```
