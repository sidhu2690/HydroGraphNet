# What changed vs. upstream `sidhu2690/HydroGraphNet`

This is the Aji-4 edition of HydroGraphNet. It is the **upstream repository with three
files edited** — `hydrographnet/dataset.py`, `train.py`, `evaluate.py` — plus two new
config files and one helper script. Everything else is byte-identical to upstream.

```
upstream (main)                     this edition
------------------------------      ------------------------------------------------
hydrographnet/dataset.py       ->   rewritten loader (the only big change)
hydrographnet/graph.py         ->   untouched
hydrographnet/models.py        ->   untouched   (pure MLP-MeshGraphNet, no KAN)
hydrographnet/losses.py        ->   untouched   (L_pred = 0.5*MSE_dWD + 0.5*MSE_dV)
hydrographnet/metrics.py       ->   untouched
train.py                       ->   edited    (two splits, onset log, grad accum)
evaluate.py                    ->   edited    (3-channel forcing, baselines, --split)
configs/config.yaml            ->   replaced by configs/aji4.yaml
configs/sample_cpu.yaml        ->   replaced by configs/aji4_subset_cpu.yaml
                                    + configs/aji4_full_smoke_cpu.yaml
scripts/download_data.py       ->   removed (see "What was deleted")
White_River_M80.ipynb, PDFs,
assets/, sample outputs         ->   removed
tools/make_subset.py           ->   NEW: builds a small runnable subset
docs/CHANGES.md                ->   NEW: this file
```

Verification of the claim above:

```bash
diff -q upstream_repo/hydrographnet/models.py  aji4_gnn/hydrographnet/models.py
diff -q upstream_repo/hydrographnet/graph.py   aji4_gnn/hydrographnet/graph.py
diff -q upstream_repo/hydrographnet/losses.py  aji4_gnn/hydrographnet/losses.py
diff -q upstream_repo/hydrographnet/metrics.py aji4_gnn/hydrographnet/metrics.py
# all four print nothing: identical
```

Line counts: `dataset.py` 448 → 729, `train.py` 286 → 306, `evaluate.py` 336 → 370.

---

## 1. The feature set the model sees

Upstream was built for the White River (Indiana) dataset: 1,000-ish cells, 3 static
features, 2 dynamic history channels, and a 3-split (train/val/test) protocol.

Aji-4 is a HEC-RAS 2D model of the Aji-4 dam on the Aji river, Gujarat (22.714 N,
70.482 E): **15,990 cells (~80 m), 103.6 km², 272 floods × 181 rows at 30 min (0–90 h)**.

### Node features: 16 per node at `n_time_steps = 2`

| slice | count | contents | change |
|---|---|---|---|
| `[0:2]` | 2 | `x`, `y` (normalised cell coordinates) | unchanged |
| `[2:9]` | 7 | `CA CE CS A CU N FA` | **9 → 7**: `IP` (infiltration) dropped |
| `[9:12]` | 3 | normalised `release`, `inflow`, `hour` | **new**: replaces upstream's 1-channel `Pr` |
| `[12:14]` | 2 | water-depth history (2 steps) | unchanged |
| `[14:16]` | 2 | volume history (2 steps) | **added**: Aji-4 ships volume natively |

Upstream's node input was 11 at `K=2` (`2 xy + 3 static + 1 Pr + 2 wd + ...`); this is 16.
`dataset.py` exposes `node_input_dim` and `configs/*.yaml` sets `input_dim_nodes: 16`, so
the model constructor stays untouched.

### The forcing channels, exactly

* **`release`** = `M80_US_InF_<hid>.txt` column 1. In this dataset `US_InF` is the **dam
  release** (reservoir → flood plain), sampled 0–90 h. It is the analogue of upstream's
  upstream-inflow term and it is the channel that actually drives the flood wave.
* **`inflow`** = reservoir inflow (`reservoir_inflow_hourly.csv`,
  columns `flood, hour, inflow_m3s`, 272 floods × 101 hourly samples, 0–100 h). This is the
  catchment → reservoir inflow, a **different file and a different quantity** from
  `US_InF`. **This is the new one.**
* **`hour`** = row index × `delta_t` / 3600. Upstream had a `hour` channel in its White
  River pipeline; Aji-4 rows carry no time column, so it is recomputed from `delta_t`.
  `dynamic_norm_stats.json` shipped with the dataset has no `hour` key — that is handled
  (see §5).

**Dropped on purpose:**

* `_IP_` (infiltration) — the Aji-4 package has no such file. Keeping a placeholder column
  would be a zero channel with no physical meaning.
* `_Pr_` (precipitation) — every `M80_Pr_*.txt` in this package is **all zeros**. Feeding a
  constant zero channel teaches the model nothing and only adds input dimension, so it was
  removed rather than left in. This was an explicit request and it is the reason the static
  block dropped from 9 to 7 and the count went to 3 forcing channels.

### Target

Unchanged: `[Δdepth, Δvolume]` per node, `L_pred = 0.5·MSE(Δdepth) + 0.5·MSE(Δvolume)`.
`models.py` and `losses.py` were not touched.

---

## 2. Two splits, not three

Upstream trains on `train.txt`, early-stops on `val.txt`, reports on `test.txt`.

This edition **pools train + val into a single training set** and reports on test:

| split | files used | floods |
|---|---|---|
| train | `train.txt` ∪ `val.txt` (via `hydrograph_ids_extra`) | 195 + 39 = **234** |
| test | `test.txt` | **38** |

There is no validation loader and no early stopping on a third split; `train.py` only
builds the test dataset for periodic rollout reporting, and checkpoints are selected by
test rollout RMSE. `configs/*.yaml` makes this explicit:

```yaml
train_ids_file: train.txt
val_ids_file: val.txt          # pooled INTO training; set to null for a 3-split run
test_ids_file: test.txt
```

---

## 3. `hydrographnet/dataset.py` — the substantial change

The loader is the only file with a real rewrite, because the two datasets are not
compatible in shape, size, or time step.

### 3.1 A cache layer, because the ASCII is 7.7 GB

`M80_WD_<hid>.txt` is 181 × 15,990 floats of ASCII (~2,900 chars/row, ~28 MB per flood;
`WD` + `V` = 7.7 GB of the 13 GB package). Parsing that twice per epoch is not viable, so
`_build_cache` converts each flood once to `float32 .npy` under
`.cache_npy/v1_s<skip>_i<interval>/` (5.0 GB for the full package), sliced from the burst
onset and strided by `interval` at build time.

`_MmapCache` is a small LRU of open memmaps (`mmap_cache_size`, default 2 in the configs).
`__getitem__` never holds a whole flood: it reads only the `K+1` rows it needs for a
training window, or `K+R` rows for a rollout. This is what makes the package loadable on a
2 GB machine at all.

### 3.2 Streaming statistics instead of `np.concatenate`

Upstream computes mean/std by concatenating every window into one array. On the full
package that array is **2.11 GiB** — an instant failure here. `_compute_dynamic_stats` now
makes a single pass over the memmap in 8-row chunks accumulating `sum`, `sum²`, `count` in
float64, which gives the same mean and variance with a peak of a few MB.

### 3.3 Burst onset instead of `skip=72`

Aji-4 floods open with a HEC-RAS start-up burst: the dam release spikes, the mesh fills,
and depth/volume settle within the first few hours. Upstream's rule (`skip` the first N
rows) is wrong here — truncating at a fixed row cuts the real peak in 47 of 272 floods even
at the README's own suggestion.

`detect_burst_end(hid, min_row=8, max_row=40, tol=0.10)` finds the trough of `US_InF` in
rows 8–40, accepts it only if the trough is below half the peak (otherwise it is not a
burst), then returns the first row within 10 % of that trough. Measured onsets on the
subset: R001 → 26, R002 → 17, R004 → 31; subset train range 17–32, median 29 (≈14.5 h).
`skip_initial_steps: auto` selects it; an integer still works if you want the old rule.

### 3.4 Time step

`delta_t` is a constructor argument (default `1800.0` for Aji-4); upstream hard-coded the
White River `1200` s. It is used for the `hour` channel and for every volume metric.

### 3.5 Volume

Aji-4 ships `M80_V_<hid>.txt`. Upstream derived storage from a depth sum. Here volume is a
real input channel and a real prediction target, so the model learns `ΔV` directly and
`metrics.py` can report volume error in Mm³. `metrics.py` itself is untouched — the
volume metrics already existed upstream.

---

## 4. `train.py`

* `hydrograph_ids_extra=val_ids_file` — the two-split merge (§2).
* `skip="auto"`, `delta_t`, `mmap_cache_size` passed through from the config.
* Banner reports node width, window count, onset range and test rollout count, so a run is
  self-describing in the log.
* `best.pt` is written even when no test set is configured (upstream only saved on
  validation improvement).
* `grad_accum_steps` (new, default 1): accumulate over N batches before stepping. With
  15,990 nodes per flood, a batch of 2 needs >1.3 GB of activations for the processor; a
  `batch_size: 1` + `grad_accum_steps: 8` run gets the same effective batch on a small box.

## 5. `evaluate.py`

* Rollout driver stacks the **three** forcing channels (`release_seq`, `inflow_seq`,
  `hour_seq`) instead of upstream's single `Pr` sequence.
* `T_roll` is derived from the length of the release sequence, not from the depth tensor.
* Static slice is `g.x[:, :9]` (2 xy + 7 static) — was `g.x[:, :5]`.
* `delta_t` from config for the volume/time metrics.
* `compute_baselines=True`: reports **persistence** (clamp the t0 depth and hold it) and a
  **zero-forecast** RMSE alongside the model, drawn as dashed lines on
  `rmse_over_time.png`. Without them a rollout RMSE has no scale.
* `--split {test,train}` to run the same evaluation against the training ids.

---

## 6. Configs and tooling

`configs/aji4.yaml` — the real recipe: hidden 64, 5 processor segments, batch 8, 150
epochs, cosine 3e-4, random-walk input noise 0.01, `delta_t: 1800.0`, 60 rollout steps.

`configs/aji4_subset_cpu.yaml` — CPU-runnable subset: hidden 32, 2 processor segments,
batch 2, 12 epochs × 30 steps. 26,274 parameters.

`configs/aji4_full_smoke_cpu.yaml` — **smoke test for the whole 272-flood package**, not a
training recipe: batch 1, `grad_accum_steps: 8`, 2 epochs × 25 steps, only to prove the
full loader and the full graph run end to end.

`tools/make_subset.py` — copies N train/val/test floods plus the statics, metadata and the
reservoir CSV into `data/aji4_subset_G1O/`, so the pipeline can be demonstrated without
materialising 7.7 GB. It preserves the train/val/test file structure exactly.

## 7. What was deleted from the upstream copy

`White_River_M80.ipynb`, `HydroGraphNet_Final_00.pdf`, `assets/`, `outputs_best/`,
`outputs_sample/`, `checkpoints_sample/`, `best_checkpoints/`, `scripts/` and the two
White-River configs. None of it applies to Aji-4; `scripts/download_data.py` in particular
fetches the White River archive, which is not what this tree trains on.

---

## 8. Known limitations

* Upstream's MeshGraphNet processor is compute-hungry at 15,990 nodes: one training step
  with `batch_size: 1` takes ≈1.0 s on 2 CPU cores, and a batch of 2 needs more memory
  than this machine has. That is an upstream `models.py` property, not a change made here;
  a GPU is the intended environment.
* The subset numbers in `outputs_subset/` come from 6 training floods and 2 test floods and
  are a pipeline demonstration, not a model-quality claim.
