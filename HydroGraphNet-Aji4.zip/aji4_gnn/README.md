# HydroGraphNet — Aji-4 dam edition

Flood forecasting on the **Aji-4 dam** HEC-RAS 2D mesh (Gujarat, India;
15,990 cells, 272 floods, 30-min rows) built as a **minimal modification** of
[`sidhu2690/HydroGraphNet`](https://github.com/sidhu2690/HydroGraphNet).

Upstream is the White River (Indiana) benchmark. Three files were edited to run on
Aji-4 — `hydrographnet/dataset.py`, `train.py`, `evaluate.py` — and `graph.py`,
`models.py`, `losses.py`, `metrics.py` are untouched. **Read
[`docs/CHANGES.md`](docs/CHANGES.md) for the complete file-by-file diff**; the short
version:

| | upstream | this edition |
|---|---|---|
| static features | 9 (incl. `IP`, `Pr`) | **7** — `IP` (infiltration) and `Pr` (precipitation) dropped |
| forcing | 1 (`Pr`) | **3** — dam release `US_InF`, reservoir inflow, hour |
| node features (K=2) | 11 | **16** (2 xy + 7 static + 3 forcing + 2 depth + 2 volume) |
| splits | train / val / test | **train+val pooled → train**, test only |
| prediction target | Δdepth | Δdepth **and** Δvolume |
| gate package | — | **G1O** only |

`G1O` is the gate package with **gate group 1 open** (groups are 1 / 1+2 / 1+2+3 for
`G1O` / `G12O` / `G123O`; the trailing character is a letter O).

## Data

Download the `aji4_flood_data_G1O` archive and point `data_dir` at the extracted
directory. The layout it expects is the one shipped:

```
aji4_flood_data_G1O/
  M80_{CA,CE,CS,A,CU,N,FA}.txt      static cell attributes (15,990 rows)
  M80_WD_<hid>.txt                  water depth   (181 x 15,990)
  M80_V_<hid>.txt                   volume        (181 x 15,990)
  M80_US_InF_<hid>.txt              dam release   (181 x 2: hour, m3/s)
  reservoir_inflow_hourly.csv       reservoir inflow (flood, hour, inflow_m3s)
  train.txt val.txt test.txt        hydrograph ids
```

`M80_Pr_*.txt` exists in the package but is **all zeros** and is not read.
`M80_IP.txt` is **not read** either. Neither is needed.

## Run it

```bash
pip install -r requirements.txt

# 1) full package, smoke test (2 epochs x 25 steps: proves the 272-flood loader runs)
python train.py --config configs/aji4_full_smoke_cpu.yaml

# 2) small runnable subset, then evaluate it
python tools/make_subset.py --src /path/to/aji4_flood_data_G1O --dst ./data/aji4_subset_G1O
python train.py --config configs/aji4_subset_cpu.yaml
python evaluate.py --config configs/aji4_subset_cpu.yaml

# 3) the intended recipe (GPU)
python train.py --config configs/aji4.yaml
```

`skip_initial_steps: auto` finds where each flood's HEC-RAS start-up burst has drained
away (rows 8–39 here); an integer still forces a fixed start row.

## Results

See [`RESULTS.md`](RESULTS.md) for the numbers produced by the subset run and the
full-package smoke run, and `outputs_subset/` for the figures and JSON metrics.
`evaluate.py` reports persistence and zero-forecast baselines next to the model, so a
rollout RMSE can be read at a glance.

---

## Upstream background

The base repository is a standalone PyTorch rewrite of **HydroGraphNet**
(*Taghizadeh et al., 2025*) for 2D flood forecasting on unstructured meshes, originally
wired to the **White River (`M80`)** benchmark (`Zenodo 15491288`). Its architectural
choices are unchanged here: `MeshGraphMLP` instead of `MeshGraphKAN`, and a pure 1-step
`L_pred` objective instead of the multi-term `pushforward + L_phys + L_pen`.

---

## 1. How to Use

### Installation

No `physicsnemo`, `dgl`, `torch_geometric`, or `torch_scatter` C++/CUDA extensions are required.

```bash
cd aji4_gnn
pip install -r requirements.txt

# Install CUDA-enabled PyTorch matching your GPU driver if not already installed, e.g.:
# pip install torch --index-url https://download.pytorch.org/whl/cu124
```

### Data

Point `data_dir` in the config at an extracted `aji4_flood_data_G1O` directory (layout in §Data
above). Nothing is downloaded by this repo — `scripts/` was removed on purpose.

### Train / evaluate

```bash
python train.py    --config configs/aji4_subset_cpu.yaml
python evaluate.py --config configs/aji4_subset_cpu.yaml
```

See §Run it at the top for the full-package smoke config and the GPU recipe.

**Scaling model capacity (`configs/config.yaml`):**
- Default matches **Paper Table 2**: `hidden_dim: 64`, `processor_size: 5` (**214,210 parameters**).
- For larger GPUs: set `hidden_dim: 128` and `processor_size: 15` (and optionally `checkpoint_segments: 3` for large batch sizes).
- `do_concat_trick: true` is enabled by default in `MeshEdgeBlock` (projects node features before edge gather, cutting edge-MLP FLOPs without changing model expressiveness).

---

## 3. What Changed vs. Official HydroGraphNet & Key Advantages

| Component | Official `NVIDIA/physicsnemo` HydroGraphNet | This Clean Rewrite |
|---|---|---|
| **Node Encoder** | Fourier-sum `KolmogorovArnoldNetwork` (`cos`/`sin` harmonics, parameter blowup, rollout sensitivity) | Standard `MeshGraphMLP` (`Linear -> SiLU -> ... -> Linear -> LayerNorm`) |
| **Training Loss** | `L_pred + L_stab (2-step pushforward) + L_phys + 0.1 * L_pen` | **Pure 1-step `L_pred`** with Pfaff et al. (2020) drift-corrected random-walk noise |
| **Graph Backend** | Requires `physicsnemo`, `dgl` / `torch_geometric` C++ extensions | **100% pure PyTorch** (`Tensor.index_add_`) |
| **Boundary Forcing** | Off-by-one mismatch between training and rollout indexing | Consistent `s -> s+1` uses `[inflow[s+1], precip[s+1]]` everywhere |
| **Test Metrics** | Reported z-scored normalized MSE | Denormalized physical **`RMSE (m)`**, **`MAE (m)`**, **`NSE`**, **`CSI@0.05m/0.30m`**, **`VolErr (%)`** |
| **Data Loading** | `np.loadtxt` (~5s per ASCII table on every run) | `np.fromstring` + automatic `.cache_npz/` (`<1s` cached) |

### Practical Advantages
1. **~3× Faster Training Steps & >50% Lower Peak GPU Memory**: Replacing 2-step pushforward (3 forward + 2 backward passes per batch) + physics reductions with 1-step `L_pred` + random-walk noise cuts per-step compute by ~3× and halves activation memory.
2. **Higher Long-Horizon Rollout Accuracy & Better Mass Balance**: Avoiding approximate physics-bound conflicts yields lower 20.7-hour rollout RMSE, higher NSE, and lower total basin volume error on unseen flood events.
3. **Zero Dependency Hell**: Runs anywhere standard `torch` runs (single GPU, `torchrun` multi-GPU DDP, Apple MPS, or CPU).

---


## 4. Experimental Findings: Why `L_phys` and `L_pen` Were Removed

Controlled identical-seed (`seed=42`, identical initial weights and mini-batch sequence) ablations on the real White River mesh (`M80`, `4,787` nodes, `19,148` directed edges; `H1..H6` train, `T1..T3` unseen **62-step / 20.7-hour** full-event rollouts; raw data in `assets/ablation_results.json`) established four findings:

1. **`L_phys` is redundant with `L_pred` (and conflicts with ground truth on heavy-rain steps)**:
   - `L_pred` already supervises exact conservative HEC-RAS cell volume increments $\Delta V_{v,\text{GT}}$ at every node, whereas `L_phys` only penalizes the basin-wide scalar sum $\sum_v \hat{\Delta V}_v$ (giving every dry hilltop and deep channel cell the exact same uniform scalar gradient). When `L_phys` fires early in training, its parameter gradient has **`+0.94` to `+0.96` cosine similarity** with $\nabla_\theta L_{\text{pred}}$.
   - Because open downstream outflow $Q_{\text{out}}(t) \ge 0$ is unmodeled in the inequality bound, `L_phys` has a median **dead-zone slack of `134,461 m³`** (`407,479 m³` at p90) where `ReLU == 0`.
   - Conversely, on **`4.2%` (`16/384`)** of training windows, **exact HEC-RAS ground truth itself violates the paper's `L_phys` bound** because `infiltration_area_sum = sum(IP * A) / 100` ignores runoff from saturated pervious soils — causing $\nabla_\theta L_{\text{phys}}$ to fight ground truth (`cos = -0.78`) late in training.
2. **`L_pen` ($\text{ReLU}(\hat{V}_v/A_v - \hat{h}_v)^2$) contributes `<0.04%` gradient norm**:
   - Across training, $\|\nabla_\theta(0.1\,L_{\text{pen}})\|_2 / \|\nabla_\theta L_{\text{pred}}\|_2 \approx 10^{-4}\text{–}4\times 10^{-4}$, changing 20.7-hour rollout RMSE by `0.0001 m` (`0.1 mm`).
3. **Pure `L_pred` passively drives both `L_phys` and `L_pen` down by 150×–250×**:
   - Without ever backpropagating `L_phys` or `L_pen`, training on `L_pred` alone reduced passive `L_phys` from `6.12e-4` to `4.15e-6` and passive `0.1 * L_pen` from `2.44e-5` to `9.85e-8`.

### Controlled Ablation Summary (Unseen 62-Step / 20.7 h Test Rollout on `T1..T3`)

| Variant | Objective | Train Time (CPU) | 5.0 h RMSE (m) | **20.7 h RMSE (m)** | **20.7 h NSE** | **Basin Vol Err (%)** | **Rollout Cont. Viol ($\text{m}^2$)** |
|---|---|---|---|---|---|---|---|
| `PF Full` (100 st) | `PF + L_pred + L_phys + L_pen` | `166.6s` | `0.1194` | `0.3339` | `0.7850` | `34.35%` | `1.03e-06` |
| `PF NoPen` (100 st) | `PF + L_pred + L_phys` | `141.8s` | `0.1195` | `0.3340` | `0.7848` | `34.27%` | `1.02e-06` |
| `PF PredOnly` (100 st) | `PF + L_pred` | `128.7s` | `0.1193` | `0.3346` | `0.7837` | `32.53%` | `8.77e-07` |
| `1S + Phys + Pen` (100 st) | `1-Step + L_pred + L_phys + L_pen` | `58.9s` | `0.1197` | `0.3124` | `0.8189` | `18.99%` | `3.40e-09` |
| **`1S Pure L_pred` (100 st)** | **`1-Step Pure L_pred` ONLY** | **`55.9s`** | **`0.1185`** | **`0.3016`** | **`0.8311`** | **`17.61%`** | **`0.00e+00`** |
| `1S + Phys + Pen` (450 st) | `1-Step + L_pred + L_phys + L_pen` | `122.6s` | `0.1130` | `0.2866` | `0.8456` | `26.93%` | `6.48e-08` |
| **`1S Pure L_pred` (450 st)** | **`1-Step Pure L_pred` ONLY** | **`118.0s`** | **`0.1106`** | **`0.2689`** | **`0.8651`** | **`23.00%`** | **`1.69e-08`** |
| **`Cleaned Repo Sample`** (`sample_cpu.yaml`, 4 ep / 180 st) | **Drift-Corrected `1-Step Pure L_pred`** | **`93.2s`** | **`0.1142`** | **`0.2709`** | **`0.8653`** | **`13.71%`** | **`0.00e+00`** |

### Experiment & Rollout Figures

The upstream White-River ablation figures lived in `assets/`, which is not part of this
edition. The Aji-4 figures produced here are in `outputs_subset/`:

- `outputs_subset/rmse_over_time.png` — rollout RMSE vs. horizon, with the persistence and
  zero-forecast baselines as dashed lines.
- `outputs_subset/rollout_R004.png`, `rollout_R008.png` — 40-step (20 h) rollouts on the
  two subset test floods.
- `outputs_subset/evaluation_metrics.json`, `training_history.json` — the numbers.
