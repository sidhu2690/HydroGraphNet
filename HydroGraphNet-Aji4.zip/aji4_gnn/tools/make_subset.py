#!/usr/bin/env python3
"""Build a small self-contained Aji-4 subset (ASCII tables + metadata) for smoke tests.

    python tools/make_subset.py --src /path/to/aji4_flood_data_G1O --dst data/aji4_subset_G1O

Copies the 9 static files, every metadata file, and the WD/V/US_InF/Pr tables for the
chosen floods, then rewrites train.txt / val.txt / test.txt to those floods only.
"""
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

STATIC = ["XY", "CA", "CE", "CS", "A", "CU", "N", "FA", "IP"]
META = [
    "floods.csv", "dynamic_norm_stats.json", "static_norm_stats.json",
    "reservoir_inflow_hourly.csv", "mesh_cells_utm42n.csv", "README.md", "MD5SUMS.txt",
]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", type=Path, required=True)
    ap.add_argument("--dst", type=Path, required=True)
    ap.add_argument("--train", nargs="+", required=True)
    ap.add_argument("--val", nargs="+", default=[])
    ap.add_argument("--test", nargs="+", required=True)
    args = ap.parse_args()

    dst = args.dst
    dst.mkdir(parents=True, exist_ok=True)
    for k in STATIC:
        shutil.copy(args.src / f"M80_{k}.txt", dst / f"M80_{k}.txt")
    for m in META:
        p = args.src / m
        if p.is_file():
            shutil.copy(p, dst / m)

    ids = list(dict.fromkeys(args.train + args.val + args.test))
    for hid in ids:
        for kind in ("WD", "V", "US_InF", "Pr"):
            f = args.src / f"M80_{kind}_{hid}.txt"
            if not f.is_file():
                raise FileNotFoundError(f)
            shutil.copy(f, dst / f.name)

    for name, lst in (("train", args.train), ("val", args.val), ("test", args.test)):
        if lst:
            (dst / f"{name}.txt").write_text("\n".join(lst) + "\n")

    n = len(list(dst.iterdir()))
    size = sum(f.stat().st_size for f in dst.iterdir()) / 1e6
    print(f"{dst}: {n} files, {size:.0f} MB | train {len(args.train)} val {len(args.val)} "
          f"test {len(args.test)} -> {ids}")


if __name__ == "__main__":
    main()
